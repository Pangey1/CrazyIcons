#include <windows.h>
#include <cmath>
#include <cstdlib>
#include <ctime>
// Принудительно подключаем системную библиотеку Shell32 для ExtractIconExW
#pragma comment(lib, "shell32.lib")
volatile bool g_Running = true;
// Структура для управления траекторией движения каждой змейки указателей
struct GlitchElement {
    HICON hIcon;
    HCURSOR hCursor; 
    bool isCursor;   
    float x, y;
    float dx, dy;
    int patternType; // 0 - хаос, 1 - волна, 2 - спираль, 3 - геометрия звезды
    float angle;
    float speed;
};
const int MAX_ELEMENTS = 50; 
GlitchElement g_Elements[MAX_ELEMENTS];
// Функция извлечения случайной иконки (1000+ вариантов из XP / Win10)
HICON GetRandomSystemIcon() {
    const wchar_t* libraries[] = { L"compstui.dll", L"pifmgr.dll", L"shell32.dll", L"imageres.dll" };
    const wchar_t* targetLib = libraries[rand() % 4];
    int iconIndex = rand() % 250; 
    
    HICON hIcon = NULL;
    ExtractIconExW(targetLib, iconIndex, NULL, &hIcon, 1);
    if (!hIcon) {
        hIcon = LoadIconW(NULL, (LPCWSTR)32513); // IDI_ERROR
    }
    return hIcon;
}
// Функция извлечения случайного системного курсора мыши
HCURSOR GetRandomSystemCursor() {
    int cursorIds[] = { 32512, 32513, 32514, 32515, 32516, 32642, 32643, 32644, 32645, 32646, 32648, 32649, 32650 };
    int targetId = cursorIds[rand() % 13];
    return LoadCursorW(NULL, (LPCWSTR)targetId);
}
// Запуск или перерождение элемента
void InitElement(int index, int cx, int cy) {
    if (rand() % 10 < 4) {
        g_Elements[index].isCursor = true;
        g_Elements[index].hCursor = GetRandomSystemCursor();
        g_Elements[index].hIcon = NULL;
    } else {
        g_Elements[index].isCursor = false;
        if (g_Elements[index].hIcon) {
            DestroyIcon(g_Elements[index].hIcon);
        }
        g_Elements[index].hIcon = GetRandomSystemIcon();
        g_Elements[index].hCursor = NULL;
    }
    
    g_Elements[index].x = (float)(rand() % cx);
    g_Elements[index].y = (float)(rand() % cy);
    g_Elements[index].dx = (float)((rand() % 16) - 8); 
    g_Elements[index].dy = (float)((rand() % 16) - 8);
    g_Elements[index].patternType = rand() % 4; 
    g_Elements[index].angle = (float)(rand() % 360);
    g_Elements[index].speed = (float)((rand() % 8) + 4);
}
// ГЛАВНЫЙ ПОТОК: Иконно-курсорный шторм (FUN_00441333 / FUN_00441427)
DWORD WINAPI GlitchStormThread(LPVOID lpParam) {
    int cx = GetSystemMetrics(0);
    int cy = GetSystemMetrics(1);
    
    for (int i = 0; i < MAX_ELEMENTS; i++) {
        InitElement(i, cx, cy);
    }
    DWORD lastSpawnTime = GetTickCount();
    SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_TIME_CRITICAL);
    while (g_Running) {
        HDC hdcScreen = GetDC(NULL);
        DWORD currentTime = GetTickCount();
        // Каждые 2 секунды подгружаем новые случайные значки и курсоры в шлейф
        if (currentTime - lastSpawnTime >= 2000) {
            for (int i = 0; i < 25; i++) {
                InitElement(rand() % MAX_ELEMENTS, cx, cy);
            }
            lastSpawnTime = currentTime;
        }
        for (int i = 0; i < MAX_ELEMENTS; i++) {
            GlitchElement& elem = g_Elements[i];
            switch (elem.patternType) {
                case 0: // Ломаные хаотичные линии
                    elem.x += elem.dx; elem.y += elem.dy;
                    if (rand() % 12 == 0) { 
                        elem.dx = (float)((rand() % 16) - 8); elem.dy = (float)((rand() % 16) - 8);
                    }
                    break;
                case 1: // Синусоидные извивающиеся змейки
                    elem.x += elem.speed; elem.y += (float)(sin(elem.angle) * 16.0);
                    elem.angle += 0.22f;
                    break;
                case 2: // Плотные 3D фрактальные спирали
                    elem.x += (float)(cos(elem.angle) * elem.speed); elem.y += (float)(sin(elem.angle) * elem.speed);
                    elem.angle += 0.12f; elem.speed += 0.05f; 
                    break;
                case 3: // Тригонометрическая звезда
                    elem.x += (float)(cos(elem.angle) * 7.0f + elem.dx * 0.4f);
                    elem.y += (float)(sin(elem.angle * 2.5f) * 11.0f + elem.dy * 0.4f);
                    elem.angle += 0.07f;
                    break;
            }
            if (elem.x < -100 || elem.x > cx + 100 || elem.y < -100 || elem.y > cy + 100) {
                InitElement(i, cx, cy); 
            }
            // Намертво отпечатываем только значки и стрелочки мыши!
            if (elem.isCursor) {
                DrawIcon(hdcScreen, (int)elem.x, (int)elem.y, (HICON)elem.hCursor);
            } else {
                DrawIcon(hdcScreen, (int)elem.x, (int)elem.y, elem.hIcon);
            }
        }
        ReleaseDC(NULL, hdcScreen);
        Sleep(8); 
    }
    for (int i = 0; i < MAX_ELEMENTS; i++) {
        if (!g_Elements[i].isCursor && g_Elements[i].hIcon) DestroyIcon(g_Elements[i].hIcon);
    }
    return 0;
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    srand((unsigned int)time(NULL));
    // Запускаем только один чистый поток значков
    HANDLE hThread = CreateThread(NULL, 0, GlitchStormThread, NULL, 0, NULL);
    while (g_Running) {
        if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) g_Running = false; // Безопасный выход на ESC
        Sleep(30);
    }
    WaitForSingleObject(hThread, 2000);
    InvalidateRect(NULL, NULL, TRUE); // Полное восстановление рабочего стола
    return 0;
}