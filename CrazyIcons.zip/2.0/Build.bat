@echo off
C:\mingw32\bin\g++.exe Main.cpp -o CrazyIcons.exe -static -lgdi32 -luser32 -lwinmm -lshell32 -mwindows
pause
